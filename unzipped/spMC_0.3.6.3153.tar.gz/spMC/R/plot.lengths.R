plot.lengths <-
function (x, ..., log = FALSE, zeros.rm = TRUE) {
  boxplot(x, ..., log = log, zeros.rm = zeros.rm)
}

