spMC

spMC: an R-package for 3D lithological reconstructions based on spatial Markov chains

Luca Sartore
Department of Environmental Sciences, Informatics and Statistics
Ca' Foscari University of Venice
Campus Scientifico, Via Torino 155
I-30172 Mestre-Venezia, Italy

Luca Sartore a), Paolo Fabbri b), Carlo Gaetan a)
a) Dipartimento di Scienze Ambientali, Informatica e Statistica, Università "Ca' Foscari" di Venezia, Campus Scientifico, Via Torino 155, I-30172 Mestre-Venezia, Italy
b) Dipartimento di Geoscienze, Università di Padova, via Gradenigo 6, 35131 Padova, Italy

